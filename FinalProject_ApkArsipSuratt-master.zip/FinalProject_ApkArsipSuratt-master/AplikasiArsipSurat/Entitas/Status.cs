﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Status
    {
        private string kode_status, nama_status;

        public string Nama_status
        {
            get { return nama_status; }
            set { nama_status = value; }
        }

        public string Kode_status
        {
            get { return kode_status; }
            set { kode_status = value; }
        }

        public Status(string kode_status, string nama_status)
        {
            this.Kode_status = kode_status;
            this.Nama_status = nama_status;
        }

    }
}
