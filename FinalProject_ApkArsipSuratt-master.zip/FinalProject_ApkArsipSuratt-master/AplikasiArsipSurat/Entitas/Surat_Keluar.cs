﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Surat_Keluar
    {
        private string kode_surat_keluar, kode_disposisi;

        public string Kode_disposisi
        {
            get { return kode_disposisi; }
            set { kode_disposisi = value; }
        }

        public string Kode_surat_keluar
        {
            get { return kode_surat_keluar; }
            set { kode_surat_keluar = value; }
        }
        public Surat_Keluar(string kode_surat_keluar, string kode_disposisi)
        {
            this.kode_surat_keluar = kode_surat_keluar;
            this.Kode_disposisi = kode_disposisi;
        }
    }
}
