﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Jenis_Surat
    {
        private string kode_jenis_surat, jenis_surat;

        public string Jenis_surat
        {
            get { return jenis_surat; }
            set { jenis_surat = value; }
        }

        public string Kode_jenis_surat
        {
            get { return kode_jenis_surat; }
            set { kode_jenis_surat = value; }
        }

        public Jenis_Surat(string kode_jenis_surat, string jenis_surat)
        {
            this.Kode_jenis_surat = kode_jenis_surat;
            this.Jenis_surat = jenis_surat;
        }
    }
}
