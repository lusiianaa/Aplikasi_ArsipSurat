﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Surat_Masuk
    {
        private string kode_surat, kode_jenis_surat, kop_surat, no_surat, perihal, isi_surat, pengirim;

        public string Pengirim
        {
            get { return pengirim; }
            set { pengirim = value; }
        }

        public string Isi_surat
        {
            get { return isi_surat; }
            set { isi_surat = value; }
        }

        public string Perihal
        {
            get { return perihal; }
            set { perihal = value; }
        }

        public string No_surat
        {
            get { return no_surat; }
            set { no_surat = value; }
        }

        public string Kop_surat
        {
            get { return kop_surat; }
            set { kop_surat = value; }
        }

        public string Kode_jenis_surat
        {
            get { return kode_jenis_surat; }
            set { kode_jenis_surat = value; }
        }

        public string Kode_surat
        {
            get { return kode_surat; }
            set { kode_surat = value; }
        }
        private DateTime tanggal_masuk;

        public DateTime Tanggal_masuk
        {
            get { return tanggal_masuk; }
            set { tanggal_masuk = value; }
        }
        
        public Surat_Masuk (string kode_surat, string kode_jenis_surat, DateTime tanggal_masuk, string kop_surat,
        string no_surat, string perihal, string isi_surat, string pengirim)
        {
            this.Kode_surat = kode_surat;
            this.Kode_jenis_surat = kode_jenis_surat;
            this.Tanggal_masuk = tanggal_masuk;
            this.Kop_surat = kop_surat;
            this.No_surat = no_surat;
            this.Perihal = perihal;
            this.Isi_surat = isi_surat;
            this.Pengirim = pengirim;
        }
    }
    
}

