﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Disposisi
    {
        private string kode_disposisi, kode_surat, kode_status, tujuan, isi, catatan;

        public string Catatan
        {
            get { return catatan; }
            set { catatan = value; }
        }

        public string Isi
        {
            get { return isi; }
            set { isi = value; }
        }

        public string Tujuan
        {
            get { return tujuan; }
            set { tujuan = value; }
        }

        public string Kode_status
        {
            get { return kode_status; }
            set { kode_status = value; }
        }

        public string Kode_surat
        {
            get { return kode_surat; }
            set { kode_surat = value; }
        }

        public string Kode_disposisi
        {
            get { return kode_disposisi; }
            set { kode_disposisi = value; }
        }

        public Disposisi(string kode_disposisi, string kode_surat, string kode_status, string tujuan, string isi, string catatan)
        {
            this.Kode_disposisi = kode_disposisi;
            this.Kode_surat = kode_surat;
            this.Kode_status = kode_status;
            this.Tujuan = tujuan;
            this.Isi = isi;
            this.Catatan = catatan;
        }

    }
}
