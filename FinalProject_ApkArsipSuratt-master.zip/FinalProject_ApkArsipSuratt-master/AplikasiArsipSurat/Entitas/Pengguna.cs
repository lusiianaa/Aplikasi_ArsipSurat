﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AplikasiArsipSurat.Entitas
{
    class Pengguna
    {
        private string kode_pengguna, username, kata_sandi, jabatan;

        public string Jabatan
        {
            get { return jabatan; }
            set { jabatan = value; }
        }

        public string Kata_sandi
        {
            get { return kata_sandi; }
            set { kata_sandi = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Kode_pengguna
        {
            get { return kode_pengguna; }
            set { kode_pengguna = value; }
        }

        public Pengguna(string kode_pengguna, string username, string kata_sandi, string jabatan)
        {
            this.Kode_pengguna = kode_pengguna;
            this.Username = username;
            this.Kata_sandi = kata_sandi;
            this.Jabatan = jabatan;
        }

    }
}
