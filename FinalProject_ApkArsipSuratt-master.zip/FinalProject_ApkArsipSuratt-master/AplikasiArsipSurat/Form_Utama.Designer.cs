﻿namespace AplikasiArsipSurat
{
    partial class Form_Utama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Utama));
            this.btnKeluar = new System.Windows.Forms.Button();
            this.panelNav = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPengguna = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnJenisSurat = new System.Windows.Forms.Button();
            this.btnStatus = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSuratMasuk = new System.Windows.Forms.Button();
            this.btnSuratKeluar = new System.Windows.Forms.Button();
            this.btnDisposisi = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnKeluar
            // 
            this.btnKeluar.BackColor = System.Drawing.Color.SlateGray;
            this.btnKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKeluar.ForeColor = System.Drawing.Color.White;
            this.btnKeluar.Location = new System.Drawing.Point(21, 597);
            this.btnKeluar.Name = "btnKeluar";
            this.btnKeluar.Size = new System.Drawing.Size(143, 23);
            this.btnKeluar.TabIndex = 7;
            this.btnKeluar.Text = "Keluar";
            this.btnKeluar.UseVisualStyleBackColor = false;
            this.btnKeluar.Click += new System.EventHandler(this.btnKeluar_Click);
            // 
            // panelNav
            // 
            this.panelNav.BackColor = System.Drawing.SystemColors.Control;
            this.panelNav.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelNav.Location = new System.Drawing.Point(186, 0);
            this.panelNav.Name = "panelNav";
            this.panelNav.Size = new System.Drawing.Size(812, 674);
            this.panelNav.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // btnPengguna
            // 
            this.btnPengguna.BackColor = System.Drawing.Color.SlateGray;
            this.btnPengguna.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPengguna.ForeColor = System.Drawing.Color.White;
            this.btnPengguna.Location = new System.Drawing.Point(21, 312);
            this.btnPengguna.Name = "btnPengguna";
            this.btnPengguna.Size = new System.Drawing.Size(143, 23);
            this.btnPengguna.TabIndex = 5;
            this.btnPengguna.Text = "Pengguna";
            this.btnPengguna.UseVisualStyleBackColor = false;
            this.btnPengguna.Click += new System.EventHandler(this.btnPengguna_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(52, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Welcome";
            // 
            // btnJenisSurat
            // 
            this.btnJenisSurat.BackColor = System.Drawing.Color.SlateGray;
            this.btnJenisSurat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJenisSurat.ForeColor = System.Drawing.Color.White;
            this.btnJenisSurat.Location = new System.Drawing.Point(21, 283);
            this.btnJenisSurat.Name = "btnJenisSurat";
            this.btnJenisSurat.Size = new System.Drawing.Size(143, 23);
            this.btnJenisSurat.TabIndex = 4;
            this.btnJenisSurat.Text = "Jenis Surat";
            this.btnJenisSurat.UseVisualStyleBackColor = false;
            this.btnJenisSurat.Click += new System.EventHandler(this.btnJenisSurat_Click);
            // 
            // btnStatus
            // 
            this.btnStatus.BackColor = System.Drawing.Color.SlateGray;
            this.btnStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStatus.ForeColor = System.Drawing.Color.White;
            this.btnStatus.Location = new System.Drawing.Point(21, 254);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(143, 23);
            this.btnStatus.TabIndex = 3;
            this.btnStatus.Text = "Status";
            this.btnStatus.UseVisualStyleBackColor = false;
            this.btnStatus.Click += new System.EventHandler(this.btnStatus_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.Controls.Add(this.btnSuratMasuk);
            this.panel1.Controls.Add(this.btnKeluar);
            this.panel1.Controls.Add(this.btnPengguna);
            this.panel1.Controls.Add(this.btnJenisSurat);
            this.panel1.Controls.Add(this.btnStatus);
            this.panel1.Controls.Add(this.btnSuratKeluar);
            this.panel1.Controls.Add(this.btnDisposisi);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(186, 674);
            this.panel1.TabIndex = 1;
            // 
            // btnSuratMasuk
            // 
            this.btnSuratMasuk.BackColor = System.Drawing.Color.SlateGray;
            this.btnSuratMasuk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuratMasuk.ForeColor = System.Drawing.Color.White;
            this.btnSuratMasuk.Location = new System.Drawing.Point(21, 167);
            this.btnSuratMasuk.Name = "btnSuratMasuk";
            this.btnSuratMasuk.Size = new System.Drawing.Size(143, 23);
            this.btnSuratMasuk.TabIndex = 8;
            this.btnSuratMasuk.Text = "Surat Masuk";
            this.btnSuratMasuk.UseVisualStyleBackColor = false;
            this.btnSuratMasuk.Click += new System.EventHandler(this.btnSuratMasuk_Click);
            // 
            // btnSuratKeluar
            // 
            this.btnSuratKeluar.BackColor = System.Drawing.Color.SlateGray;
            this.btnSuratKeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuratKeluar.ForeColor = System.Drawing.Color.White;
            this.btnSuratKeluar.Location = new System.Drawing.Point(21, 225);
            this.btnSuratKeluar.Name = "btnSuratKeluar";
            this.btnSuratKeluar.Size = new System.Drawing.Size(143, 23);
            this.btnSuratKeluar.TabIndex = 2;
            this.btnSuratKeluar.Text = "Surat Keluar";
            this.btnSuratKeluar.UseVisualStyleBackColor = false;
            this.btnSuratKeluar.Click += new System.EventHandler(this.btnSuratKeluar_Click);
            // 
            // btnDisposisi
            // 
            this.btnDisposisi.BackColor = System.Drawing.Color.SlateGray;
            this.btnDisposisi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisposisi.ForeColor = System.Drawing.Color.White;
            this.btnDisposisi.Location = new System.Drawing.Point(21, 196);
            this.btnDisposisi.Name = "btnDisposisi";
            this.btnDisposisi.Size = new System.Drawing.Size(143, 23);
            this.btnDisposisi.TabIndex = 1;
            this.btnDisposisi.Text = "Disposisi";
            this.btnDisposisi.UseVisualStyleBackColor = false;
            this.btnDisposisi.Click += new System.EventHandler(this.btnDisposisi_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(186, 157);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(38, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(99, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form_Utama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 674);
            this.Controls.Add(this.panelNav);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Utama";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnKeluar;
        private System.Windows.Forms.Panel panelNav;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPengguna;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnJenisSurat;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSuratMasuk;
        private System.Windows.Forms.Button btnSuratKeluar;
        private System.Windows.Forms.Button btnDisposisi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

