﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Disposisi
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Disposisi kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_disposisi VALUES('" + kr.Kode_disposisi + "', " +
                "'" + kr.Kode_surat + "'," +
                "'" + kr.Kode_status + "', " +
                "'" + kr.Tujuan + "', " +
                "'" + kr.Isi+ "', " +
                "'" + kr.Catatan + "')";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Disposisi kr)
        {
            temp = 0;
            query = "UPDATE tbl_disposisi SET kode_surat = '" + kr.Kode_surat + "', " +
                    "kode_status = '" + kr.Kode_status + "', " +
                    "tujuan = '" + kr.Tujuan + "', " +
                    "isi = '" + kr.Isi + "', " +
                    "catatan = '" + kr.Catatan + "' " +
                    "WHERE kode_disposisi ='" + kr.Kode_disposisi + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_disposisi WHERE kode_disposisi = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Disposisi";
                dg.Columns[1].HeaderText = "Kode Surat";
                dg.Columns[2].HeaderText = "Kode Status";
                dg.Columns[3].HeaderText = "Tujuan";
                dg.Columns[4].HeaderText = "Isi";
                dg.Columns[5].HeaderText = "Catatan";

                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }
    }
}
