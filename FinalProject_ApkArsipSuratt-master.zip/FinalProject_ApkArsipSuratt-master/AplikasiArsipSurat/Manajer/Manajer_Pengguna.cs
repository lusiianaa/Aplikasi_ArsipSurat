﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Pengguna
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Pengguna kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_pengguna VALUES('" + kr.Kode_pengguna + "', " +
                "'" + kr.Username + "'," +
                "'" + kr.Kata_sandi + "', " +
                "'" + kr.Jabatan + "')";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Pengguna kr)
        {
            temp = 0;
            query = "UPDATE tbl_pengguna SET username = '" + kr.Username + "', " +
                "kata_Sandi = '" + kr.Kata_sandi + "', " +
                "jabatan = '" + kr.Jabatan + "' " +
                "WHERE kode_pengguna = '" + kr.Kode_pengguna + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_pengguna WHERE kode_pengguna = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Pengguna";
                dg.Columns[1].HeaderText = "Username";
                dg.Columns[3].HeaderText = "Kata Sandi";
                dg.Columns[4].HeaderText = "Jabatan";

                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }
    }
}
