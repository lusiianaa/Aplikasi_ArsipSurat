﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Status
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Status kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_status VALUES('" + kr.Kode_status + "', " +
                "'" + kr.Nama_status + "')";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Status kr)
        {
            temp = 0;
            query = "UPDATE tbl_status SET nama_status = '" + kr.Nama_status + "' " +
                    "WHERE kode_status ='" + kr.Kode_status + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_status WHERE kode_status = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Status";
                dg.Columns[1].HeaderText = "Nama Status";

                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }
    }
}
