﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Surat_Keluar
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Surat_Keluar kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_surat_keluar VALUES('" + kr.Kode_surat_keluar + "', " +
                "'" + kr.Kode_disposisi + "')";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Surat_Keluar kr)
        {
            temp = 0;
            query = "UPDATE tbl_surat_keluar SET kode_disposisi= '" + kr.Kode_disposisi + "' " +
                "WHERE kode_surat_keluar ='" + kr.Kode_surat_keluar + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_surat_keluar WHERE kode_surat_keluar = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Surat Keluar";
                dg.Columns[1].HeaderText = "Kode Disposisi";
  
                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }
    }
}