﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Jenis_Surat
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Jenis_Surat kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_jenis_surat VALUES('" + kr.Kode_jenis_surat + "', " +
                "'" + kr.Jenis_surat + "')";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Jenis_Surat kr)
        {
            temp = 0;
            query = "UPDATE tbl_jenis_surat SET jenis_surat = '" + kr.Jenis_surat + "' " +
                    "WHERE kode_jenis_surat ='" + kr.Kode_jenis_surat + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_jenis_surat WHERE kode_jenis_surat = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Jenis Surat";
                dg.Columns[1].HeaderText = "Jenis Surat";

                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }
    }
}
