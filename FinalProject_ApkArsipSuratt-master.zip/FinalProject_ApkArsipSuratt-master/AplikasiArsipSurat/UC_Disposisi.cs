﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading.Tasks;
namespace AplikasiArsipSurat
{
    public partial class UC_Disposisi : UserControl
    {
        public UC_Disposisi()
        {
            InitializeComponent();
        }

        private void tampilDataDisposisi()
        {
            // string query = "select kode_jenis_surat, tanggal_masuk, kop_surat, no_surat, perihal, isi_surat, pengirim  " +
            //   "from tbl_surat_masuk where kode_surat = '" + txtKodeSurat.Text + "'";
            string query = "SELECT * FROM tbl_disposisi";
            Manajer.Manajer_Disposisi mp = new Manajer.Manajer_Disposisi();
            mp.TampilData(query, "tbl_disposisi", dgDisposisi);
        }
        private void TampilData()
        {
            string query = "select * from tbl_disposisi " +
                "where kode_disposisi ='" + txtKodeDisposisi.Text + "'";
            Manajer.Manajer_Disposisi mp = new Manajer.Manajer_Disposisi();
            mp.TampilData(query, "tbl_disposisi", dgDisposisi);
        }
        private void tampilKodeSurat()
        {
            //menampilkan data kode jenis surat
            string query = "SELECT kode_surat FROM tbl_surat_masuk";
            Fungsi.Set_Combobox(query, "kode_surat", cbSuratMasuk);
        }
        private void tampilSurat()
        {
            //menampilkan jenis surat
            string query = "SELECT kode_jenis_surat, tanggal_masuk, kop_surat, no_surat, perihal, isi_Surat, pengirim FROM tbl_surat_masuk " +
                "WHERE kode_surat = '" + cbSuratMasuk.Text + "'";
            Fungsi.Set_Textbox(query, "kode_jenis_surat", txtJenisSurat);
            Fungsi.Set_Textbox(query, "tanggal_masuk", txtTanggalMasuk);
            Fungsi.Set_Textbox(query, "kop_surat", txtKopSurat);
            Fungsi.Set_Textbox(query, "no_surat", txtNoSurat);
            Fungsi.Set_Textbox(query, "perihal", txtPerihal);
            Fungsi.Set_Textbox(query, "isi_surat", txtIsiSurat);
            Fungsi.Set_Textbox(query, "pengirim", txtPengirim);
        }

        private void tampilKodeStatus()
        {
            string query = "SELECT kode_status FROM tbl_status";
            Fungsi.Set_Combobox(query, "kode_status", cbStatus);
        }

        private void tampilStatus()
        {
            string query = "SELECT nama_status FROM tbl_status " +
                "WHERE kode_status = '" + cbStatus.Text + "'";
            Fungsi.Set_Textbox(query, "nama_status", txtNamaStatus);
        }

        private string tampilKodeDisposisi
        {
            get
            {
                SqlConnection conn = Koneksi.Conn;
                conn.Open();
                string nomor = "ABD0001";
                SqlCommand cmd = new SqlCommand("SELECT MAX(RIGHT(kode_disposisi, 7)) FROM tbl_disposisi", conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                if (sdr[0].ToString() != "")
                {
                    nomor = "ABD" + (int.Parse(sdr[0].ToString()) + 1).ToString("0000");
                    sdr.Close();
                }
                return nomor;
            }
        }

        private void UC_Disposisi_Load(object sender, EventArgs e)
        {
            tampilDataDisposisi();
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            txtKodeDisposisi.Text = tampilKodeDisposisi;
            tampilKodeSurat();
            tampilKodeStatus();

            MessageBox.Show("Data disposisi baru berhasil ditambahkan.", "Tambah Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cbSuratMasuk_SelectedIndexChanged(object sender, EventArgs e)
        {
            tampilSurat();
        }

        private void cbSuratMasuk_TextChanged(object sender, EventArgs e)
        {
            tampilSurat();
        }

        private void cbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            tampilStatus();
        }

        private void cbStatus_TextChanged(object sender, EventArgs e)
        {
            tampilStatus();
        }
        private void Clear()
        {
            txtKodeDisposisi.Clear();
            cbSuratMasuk.SelectedIndex = -1;
            cbStatus.SelectedIndex = -1;
            txtTujuan.Clear();
            txtIsi.Clear();
            txtCatatan.Clear();
            txtTujuan.Focus();

        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTujuan.Text) || string.IsNullOrWhiteSpace(txtIsi.Text) || string.IsNullOrWhiteSpace(txtCatatan.Text))
            {
                MessageBox.Show("Semua kolom harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SqlConnection koneksii = Koneksi.Conn;
            koneksii.Open();
            SqlCommand cmd = new SqlCommand("SELECT kode_disposisi, kode_surat, kode_status, tujuan, isi, catatan FROM tbl_disposisi WHERE " +
                "kode_disposisi='" + txtKodeDisposisi.Text + "' AND kode_surat='" + cbSuratMasuk.Text + "'"
                + "AND kode_status = '" + cbStatus.Text + "'");
            cmd.Connection = koneksii;
            string cek = (string)cmd.ExecuteScalar();
            koneksii.Close();

            if (string.IsNullOrEmpty(cek))
            {
                // Data tidak ada, dapat disimpan
                Entitas.Disposisi p = new Entitas.Disposisi(txtKodeDisposisi.Text, cbSuratMasuk.Text, cbStatus.Text,
                    txtTujuan.Text, txtIsi.Text, txtCatatan.Text);
                Manajer.Manajer_Disposisi mp = new Manajer.Manajer_Disposisi();

                mp.Tambah(p);
                tampilDataDisposisi();

                MessageBox.Show("Data berhasil disimpan.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Data sudah ada, tampilkan pesan peringatan
                MessageBox.Show("Data dengan kode disposisi tersebut sudah ada!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnUbah_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTujuan.Text) || string.IsNullOrWhiteSpace(txtIsi.Text) || string.IsNullOrWhiteSpace(txtCatatan.Text))
            {
                MessageBox.Show("Semua kolom harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SqlConnection koneksii = Koneksi.Conn;
            koneksii.Open();
            SqlCommand cmd = new SqlCommand("SELECT kode_surat, kode_status, tujuan, isi, catatan FROM tbl_disposisi WHERE " +
                "kode_disposisi='" + txtKodeDisposisi.Text + "' AND kode_surat='" + cbSuratMasuk.Text + "'"
                + "AND kode_status = '" + cbStatus.Text + "'");
            cmd.Connection = koneksii;
            string cek = (string)cmd.ExecuteScalar();
            koneksii.Close();

            if (!string.IsNullOrEmpty(cek))
            {
                // Data ditemukan, dapat diubah
                Entitas.Disposisi p = new Entitas.Disposisi(txtKodeDisposisi.Text, cbSuratMasuk.Text, cbStatus.Text,
                    txtTujuan.Text, txtIsi.Text, txtCatatan.Text);
                Manajer.Manajer_Disposisi mp = new Manajer.Manajer_Disposisi();

                mp.Edit(p);
                tampilDataDisposisi();

                MessageBox.Show("Data berhasil diubah.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Data tidak ditemukan, tampilkan pesan peringatan
                MessageBox.Show("Data dengan kode disposisi tersebut tidak ditemukan!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
     private void btnHapus_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Yakin Mau Hapus?", "Peringatan",
               MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                string hapuskodedisposisi = txtKodeDisposisi.Text;
                //string hapuscbSuratMasuk = cbSuratMasuk.SelectedItem.ToString();
                //string hapuscbStatus = cbStatus.SelectedItem.ToString();
                string hapusjenissurat = txtJenisSurat.Text;
                string tanggalmasuk = txtTanggalMasuk.Text;
                string kopsurat = txtKopSurat.Text;
                string nosurat = txtNoSurat.Text;
                string perihal = txtPerihal.Text;
                string isisurat = txtIsiSurat.Text;
                string pengirim = txtPengirim.Text;
                string namastatus = txtNamaStatus.Text;
                string hapustujuan = txtTujuan.Text;
                string hapusisi = txtIsi.Text;
                string hapuscatatan = txtCatatan.Text;
                Manajer.Manajer_Disposisi mm = new Manajer.Manajer_Disposisi();
                mm.Hapus(hapuskodedisposisi);
                //mm.Hapus(hapuscbSuratMasuk);
                //mm.Hapus(hapuscbStatus);
                mm.Hapus(hapusjenissurat);
                mm.Hapus(tanggalmasuk);
                mm.Hapus(kopsurat);
                mm.Hapus(nosurat);
                mm.Hapus(perihal);
                mm.Hapus(isisurat);
                mm.Hapus(pengirim);
                mm.Hapus(namastatus);
                mm.Hapus(hapustujuan);
                mm.Hapus(hapusisi);
                mm.Hapus(hapuscatatan);
            }
            tampilDataDisposisi();
            Clear();
        }
   

        private void dgDisposisi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtKodeDisposisi.Text = dgDisposisi.CurrentRow.Cells["kode_disposisi"].Value.ToString();
            cbSuratMasuk.Text = dgDisposisi.CurrentRow.Cells["kode_surat"].Value.ToString();
            cbStatus.Text = dgDisposisi.CurrentRow.Cells["kode_status"].Value.ToString();
            txtTujuan.Text = dgDisposisi.CurrentRow.Cells["tujuan"].Value.ToString();
            txtIsi.Text = dgDisposisi.CurrentRow.Cells["isi"].Value.ToString();
            txtCatatan.Text = dgDisposisi.CurrentRow.Cells["catatan"].Value.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
 

    }
}
