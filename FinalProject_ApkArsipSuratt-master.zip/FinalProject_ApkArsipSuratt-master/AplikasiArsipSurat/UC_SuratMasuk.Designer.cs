﻿namespace AplikasiArsipSurat
{
    partial class UC_SuratMasuk
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCetak = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUbah = new System.Windows.Forms.Button();
            this.dgSuratMasuk = new System.Windows.Forms.DataGridView();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.btnTambah = new System.Windows.Forms.Button();
            this.txtKopSurat = new System.Windows.Forms.TextBox();
            this.txtKodeSurat = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dt1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNoSurat = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPerihal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtIsiSurat = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPengirim = new System.Windows.Forms.TextBox();
            this.cb_JS = new System.Windows.Forms.ComboBox();
            this.tbljenissuratBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_JS = new AplikasiArsipSurat.ds_JS();
            this.tbl_jenis_suratTableAdapter = new AplikasiArsipSurat.ds_JSTableAdapters.tbl_jenis_suratTableAdapter();
            this.label11 = new System.Windows.Forms.Label();
            this.txtJenisSurat = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgSuratMasuk)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbljenissuratBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_JS)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCetak
            // 
            this.btnCetak.Location = new System.Drawing.Point(548, 284);
            this.btnCetak.Name = "btnCetak";
            this.btnCetak.Size = new System.Drawing.Size(76, 30);
            this.btnCetak.TabIndex = 105;
            this.btnCetak.Text = "Cetak";
            this.btnCetak.UseVisualStyleBackColor = true;
            this.btnCetak.Click += new System.EventHandler(this.btnCetak_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Book Antiqua", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(505, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Surat Masuk";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(474, 284);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(68, 30);
            this.btnClear.TabIndex = 104;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(14, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Arsip Surat";
            // 
            // btnUbah
            // 
            this.btnUbah.Location = new System.Drawing.Point(548, 239);
            this.btnUbah.Name = "btnUbah";
            this.btnUbah.Size = new System.Drawing.Size(76, 30);
            this.btnUbah.TabIndex = 103;
            this.btnUbah.Text = "Ubah";
            this.btnUbah.UseVisualStyleBackColor = true;
            this.btnUbah.Click += new System.EventHandler(this.btnUbah_Click);
            // 
            // dgSuratMasuk
            // 
            this.dgSuratMasuk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSuratMasuk.Location = new System.Drawing.Point(0, 368);
            this.dgSuratMasuk.Name = "dgSuratMasuk";
            this.dgSuratMasuk.Size = new System.Drawing.Size(809, 236);
            this.dgSuratMasuk.TabIndex = 99;
            this.dgSuratMasuk.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSuratMasuk_CellClick);
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(470, 239);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(72, 30);
            this.btnSimpan.TabIndex = 101;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnHapus
            // 
            this.btnHapus.Location = new System.Drawing.Point(392, 284);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(76, 30);
            this.btnHapus.TabIndex = 102;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.UseVisualStyleBackColor = true;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // btnTambah
            // 
            this.btnTambah.Location = new System.Drawing.Point(392, 239);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(72, 30);
            this.btnTambah.TabIndex = 100;
            this.btnTambah.Text = "Tambah";
            this.btnTambah.UseVisualStyleBackColor = true;
            this.btnTambah.Click += new System.EventHandler(this.btnTambah_Click);
            // 
            // txtKopSurat
            // 
            this.txtKopSurat.Location = new System.Drawing.Point(139, 162);
            this.txtKopSurat.Name = "txtKopSurat";
            this.txtKopSurat.Size = new System.Drawing.Size(214, 20);
            this.txtKopSurat.TabIndex = 96;
            // 
            // txtKodeSurat
            // 
            this.txtKodeSurat.Location = new System.Drawing.Point(139, 89);
            this.txtKodeSurat.Name = "txtKodeSurat";
            this.txtKodeSurat.Size = new System.Drawing.Size(214, 20);
            this.txtKodeSurat.TabIndex = 95;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 16);
            this.label9.TabIndex = 94;
            this.label9.Text = "Kop Surat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 16);
            this.label8.TabIndex = 93;
            this.label8.Text = "Tanggal Masuk";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(372, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 16);
            this.label4.TabIndex = 92;
            this.label4.Text = "Kode Jenis Surat";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(18, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 91;
            this.label3.Text = "Kode Surat";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(812, 61);
            this.panel1.TabIndex = 90;
            // 
            // dt1
            // 
            this.dt1.Location = new System.Drawing.Point(139, 126);
            this.dt1.Name = "dt1";
            this.dt1.Size = new System.Drawing.Size(214, 20);
            this.dt1.TabIndex = 107;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 108;
            this.label5.Text = "No Surat";
            // 
            // txtNoSurat
            // 
            this.txtNoSurat.Location = new System.Drawing.Point(139, 191);
            this.txtNoSurat.Name = "txtNoSurat";
            this.txtNoSurat.Size = new System.Drawing.Size(214, 20);
            this.txtNoSurat.TabIndex = 109;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(372, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 16);
            this.label6.TabIndex = 110;
            this.label6.Text = "Perihal";
            // 
            // txtPerihal
            // 
            this.txtPerihal.Location = new System.Drawing.Point(439, 188);
            this.txtPerihal.Name = "txtPerihal";
            this.txtPerihal.Size = new System.Drawing.Size(203, 20);
            this.txtPerihal.TabIndex = 111;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 227);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 112;
            this.label7.Text = "Isi Surat";
            // 
            // txtIsiSurat
            // 
            this.txtIsiSurat.Location = new System.Drawing.Point(139, 227);
            this.txtIsiSurat.Multiline = true;
            this.txtIsiSurat.Name = "txtIsiSurat";
            this.txtIsiSurat.Size = new System.Drawing.Size(214, 135);
            this.txtIsiSurat.TabIndex = 113;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(372, 162);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 16);
            this.label10.TabIndex = 114;
            this.label10.Text = "Pengirim";
            // 
            // txtPengirim
            // 
            this.txtPengirim.Location = new System.Drawing.Point(439, 162);
            this.txtPengirim.Name = "txtPengirim";
            this.txtPengirim.Size = new System.Drawing.Size(203, 20);
            this.txtPengirim.TabIndex = 115;
            // 
            // cb_JS
            // 
            this.cb_JS.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbljenissuratBindingSource, "jenis_surat", true));
            this.cb_JS.FormattingEnabled = true;
            this.cb_JS.Location = new System.Drawing.Point(498, 89);
            this.cb_JS.Name = "cb_JS";
            this.cb_JS.Size = new System.Drawing.Size(141, 21);
            this.cb_JS.TabIndex = 116;
            this.cb_JS.SelectedIndexChanged += new System.EventHandler(this.cb_JS_SelectedIndexChanged);
            this.cb_JS.TextChanged += new System.EventHandler(this.cb_JS_TextChanged);
            // 
            // tbljenissuratBindingSource
            // 
            this.tbljenissuratBindingSource.DataMember = "tbl_jenis_surat";
            this.tbljenissuratBindingSource.DataSource = this.ds_JS;
            // 
            // ds_JS
            // 
            this.ds_JS.DataSetName = "ds_JS";
            this.ds_JS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbl_jenis_suratTableAdapter
            // 
            this.tbl_jenis_suratTableAdapter.ClearBeforeFill = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(407, 126);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 16);
            this.label11.TabIndex = 117;
            this.label11.Text = "Jenis Surat";
            // 
            // txtJenisSurat
            // 
            this.txtJenisSurat.Location = new System.Drawing.Point(498, 129);
            this.txtJenisSurat.Name = "txtJenisSurat";
            this.txtJenisSurat.Size = new System.Drawing.Size(141, 20);
            this.txtJenisSurat.TabIndex = 118;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(630, 291);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 16);
            this.label12.TabIndex = 119;
            // 
            // UC_SuratMasuk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtJenisSurat);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cb_JS);
            this.Controls.Add(this.txtPengirim);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtIsiSurat);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPerihal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNoSurat);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dt1);
            this.Controls.Add(this.btnCetak);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnUbah);
            this.Controls.Add(this.dgSuratMasuk);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnTambah);
            this.Controls.Add(this.txtKopSurat);
            this.Controls.Add(this.txtKodeSurat);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Name = "UC_SuratMasuk";
            this.Size = new System.Drawing.Size(812, 674);
            this.Load += new System.EventHandler(this.UC_SuratMasuk_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgSuratMasuk)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbljenissuratBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_JS)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCetak;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUbah;
        private System.Windows.Forms.DataGridView dgSuratMasuk;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.TextBox txtKopSurat;
        private System.Windows.Forms.TextBox txtKodeSurat;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dt1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNoSurat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPerihal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtIsiSurat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtPengirim;
        private System.Windows.Forms.ComboBox cb_JS;
        private System.Windows.Forms.BindingSource tbljenissuratBindingSource;
        private ds_JS ds_JS;
        private ds_JSTableAdapters.tbl_jenis_suratTableAdapter tbl_jenis_suratTableAdapter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtJenisSurat;
        private System.Windows.Forms.Label label12;
    }
}
