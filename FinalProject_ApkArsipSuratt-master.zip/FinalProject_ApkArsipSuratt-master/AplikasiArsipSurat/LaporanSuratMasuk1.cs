﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AplikasiArsipSurat
{
    public partial class LaporanSuratMasuk1 : Form
    {
        public LaporanSuratMasuk1()
        {
            InitializeComponent();
        }

        private void LaporanSuratMasuk1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Laporan_SuratMasuk.tbl_surat_masuk' table. You can move, or remove it, as needed.
            this.tbl_surat_masukTableAdapter.Fill(this.Laporan_SuratMasuk.tbl_surat_masuk);

            this.reportViewer1.RefreshReport();
        }
    }
}
