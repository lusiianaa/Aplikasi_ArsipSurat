﻿namespace AplikasiArsipSurat
{
    partial class UC_SuratKeluar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbljenissuratBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ds_JS = new AplikasiArsipSurat.ds_JS();
            this.txtKodeSurat = new System.Windows.Forms.TextBox();
            this.tbl_jenis_suratTableAdapter = new AplikasiArsipSurat.ds_JSTableAdapters.tbl_jenis_suratTableAdapter();
            this.cbDisposisi = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnUbah = new System.Windows.Forms.Button();
            this.dgSuratKeluar = new System.Windows.Forms.DataGridView();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.btnTambah = new System.Windows.Forms.Button();
            this.txtKodeSuratKeluar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtTujuan = new System.Windows.Forms.TextBox();
            this.txtIsiSuratKeluar = new System.Windows.Forms.TextBox();
            this.txtCatatan = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKodeStatus = new System.Windows.Forms.TextBox();
            this.btnCetak1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tbljenissuratBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_JS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSuratKeluar)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbljenissuratBindingSource
            // 
            this.tbljenissuratBindingSource.DataMember = "tbl_jenis_surat";
            this.tbljenissuratBindingSource.DataSource = this.ds_JS;
            // 
            // ds_JS
            // 
            this.ds_JS.DataSetName = "ds_JS";
            this.ds_JS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtKodeSurat
            // 
            this.txtKodeSurat.Location = new System.Drawing.Point(149, 138);
            this.txtKodeSurat.Name = "txtKodeSurat";
            this.txtKodeSurat.Size = new System.Drawing.Size(93, 20);
            this.txtKodeSurat.TabIndex = 144;
            // 
            // tbl_jenis_suratTableAdapter
            // 
            this.tbl_jenis_suratTableAdapter.ClearBeforeFill = true;
            // 
            // cbDisposisi
            // 
            this.cbDisposisi.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tbljenissuratBindingSource, "jenis_surat", true));
            this.cbDisposisi.FormattingEnabled = true;
            this.cbDisposisi.Location = new System.Drawing.Point(149, 111);
            this.cbDisposisi.Name = "cbDisposisi";
            this.cbDisposisi.Size = new System.Drawing.Size(141, 21);
            this.cbDisposisi.TabIndex = 142;
            this.cbDisposisi.SelectedIndexChanged += new System.EventHandler(this.cbDisposisi_SelectedIndexChanged);
            this.cbDisposisi.TextChanged += new System.EventHandler(this.cbDisposisi_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Book Antiqua", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(371, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Surat Keluar";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(351, 322);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(68, 30);
            this.btnClear.TabIndex = 131;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUbah
            // 
            this.btnUbah.Location = new System.Drawing.Point(187, 322);
            this.btnUbah.Name = "btnUbah";
            this.btnUbah.Size = new System.Drawing.Size(76, 30);
            this.btnUbah.TabIndex = 130;
            this.btnUbah.Text = "Ubah";
            this.btnUbah.UseVisualStyleBackColor = true;
            this.btnUbah.Click += new System.EventHandler(this.btnUbah_Click);
            // 
            // dgSuratKeluar
            // 
            this.dgSuratKeluar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSuratKeluar.Location = new System.Drawing.Point(10, 358);
            this.dgSuratKeluar.Name = "dgSuratKeluar";
            this.dgSuratKeluar.Size = new System.Drawing.Size(658, 352);
            this.dgSuratKeluar.TabIndex = 126;
            this.dgSuratKeluar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSuratKeluar_CellClick);
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(109, 322);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(72, 30);
            this.btnSimpan.TabIndex = 128;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnHapus
            // 
            this.btnHapus.Location = new System.Drawing.Point(269, 322);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(76, 30);
            this.btnHapus.TabIndex = 129;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.UseVisualStyleBackColor = true;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // btnTambah
            // 
            this.btnTambah.Location = new System.Drawing.Point(31, 322);
            this.btnTambah.Name = "btnTambah";
            this.btnTambah.Size = new System.Drawing.Size(72, 30);
            this.btnTambah.TabIndex = 127;
            this.btnTambah.Text = "Tambah";
            this.btnTambah.UseVisualStyleBackColor = true;
            this.btnTambah.Click += new System.EventHandler(this.btnTambah_Click);
            // 
            // txtKodeSuratKeluar
            // 
            this.txtKodeSuratKeluar.Location = new System.Drawing.Point(149, 79);
            this.txtKodeSuratKeluar.Name = "txtKodeSuratKeluar";
            this.txtKodeSuratKeluar.Size = new System.Drawing.Size(141, 20);
            this.txtKodeSuratKeluar.TabIndex = 124;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(14, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Arsip Surat";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(28, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 16);
            this.label4.TabIndex = 121;
            this.label4.Text = "KodeDisposisi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 16);
            this.label3.TabIndex = 120;
            this.label3.Text = "Kode Surat Keluar";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1014, 61);
            this.panel1.TabIndex = 119;
            // 
            // txtTujuan
            // 
            this.txtTujuan.Location = new System.Drawing.Point(149, 164);
            this.txtTujuan.Name = "txtTujuan";
            this.txtTujuan.Size = new System.Drawing.Size(185, 20);
            this.txtTujuan.TabIndex = 145;
            // 
            // txtIsiSuratKeluar
            // 
            this.txtIsiSuratKeluar.Location = new System.Drawing.Point(149, 190);
            this.txtIsiSuratKeluar.Multiline = true;
            this.txtIsiSuratKeluar.Name = "txtIsiSuratKeluar";
            this.txtIsiSuratKeluar.Size = new System.Drawing.Size(284, 116);
            this.txtIsiSuratKeluar.TabIndex = 146;
            // 
            // txtCatatan
            // 
            this.txtCatatan.Location = new System.Drawing.Point(452, 164);
            this.txtCatatan.Multiline = true;
            this.txtCatatan.Name = "txtCatatan";
            this.txtCatatan.Size = new System.Drawing.Size(247, 66);
            this.txtCatatan.TabIndex = 147;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(449, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 148;
            this.label5.Text = "Catatan";
            // 
            // txtKodeStatus
            // 
            this.txtKodeStatus.Location = new System.Drawing.Point(248, 139);
            this.txtKodeStatus.Name = "txtKodeStatus";
            this.txtKodeStatus.Size = new System.Drawing.Size(86, 20);
            this.txtKodeStatus.TabIndex = 149;
            // 
            // btnCetak1
            // 
            this.btnCetak1.Location = new System.Drawing.Point(425, 322);
            this.btnCetak1.Name = "btnCetak1";
            this.btnCetak1.Size = new System.Drawing.Size(68, 30);
            this.btnCetak1.TabIndex = 150;
            this.btnCetak1.Text = "Cetak";
            this.btnCetak1.UseVisualStyleBackColor = true;
            this.btnCetak1.Click += new System.EventHandler(this.btnCetak1_Click);
            // 
            // UC_SuratKeluar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnCetak1);
            this.Controls.Add(this.txtKodeStatus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCatatan);
            this.Controls.Add(this.txtIsiSuratKeluar);
            this.Controls.Add(this.txtTujuan);
            this.Controls.Add(this.txtKodeSurat);
            this.Controls.Add(this.cbDisposisi);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnUbah);
            this.Controls.Add(this.dgSuratKeluar);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnTambah);
            this.Controls.Add(this.txtKodeSuratKeluar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Name = "UC_SuratKeluar";
            this.Size = new System.Drawing.Size(1014, 713);
            this.Load += new System.EventHandler(this.UC_SuratKeluar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tbljenissuratBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ds_JS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgSuratKeluar)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource tbljenissuratBindingSource;
        private ds_JS ds_JS;
        private System.Windows.Forms.TextBox txtKodeSurat;
        private ds_JSTableAdapters.tbl_jenis_suratTableAdapter tbl_jenis_suratTableAdapter;
        private System.Windows.Forms.ComboBox cbDisposisi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnUbah;
        private System.Windows.Forms.DataGridView dgSuratKeluar;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.Button btnTambah;
        private System.Windows.Forms.TextBox txtKodeSuratKeluar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtTujuan;
        private System.Windows.Forms.TextBox txtIsiSuratKeluar;
        private System.Windows.Forms.TextBox txtCatatan;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKodeStatus;
        private System.Windows.Forms.Button btnCetak1;

    }
}
