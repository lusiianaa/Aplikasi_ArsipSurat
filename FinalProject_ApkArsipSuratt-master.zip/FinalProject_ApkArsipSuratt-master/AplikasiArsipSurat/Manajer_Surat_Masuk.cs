﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace AplikasiArsipSurat.Manajer
{
    class Manajer_Surat_Masuk
    {
        static int temp;
        static string query;

        public int Tambah(Entitas.Surat_Masuk kr)
        {
            temp = 0;
            query = "INSERT INTO tbl_surat_masuk VALUES('" + kr.Kode_surat + "', " +
                "'" + kr.Kode_jenis_surat + "'," +
                "'" + kr.Tanggal_masuk + "', " +
                "'" + kr.Kop_surat + "', " +
                "'" + kr.No_surat + "', " +
                "'" + kr.Perihal + "', " +
                "'" + kr.Isi_surat + "', " +
                "'" + kr.Pengirim + "')";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Edit(Entitas.Surat_Masuk kr)
        {
            temp = 0;
            query = "UPDATE tbl_surat_masuk SET kode_jenis_surat= '" + kr.Kode_jenis_surat + "', " +
                "tanggal_masuk = '" + kr.Tanggal_masuk + "', " +
                "kop_surat = '" + kr.Kop_surat + "', " +
                "no_surat = '" + kr.No_surat + "', " +
                "perihal = '" + kr.Perihal + "', " +
                "isi_surat = '" + kr.Isi_surat + "', " +
                "pengirim = '" + kr.Pengirim + "' " +
                "WHERE kode_surat ='" + kr.Kode_surat + "'";

            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public int Hapus(string ha)
        {
            temp = 0;
            query = "DELETE FROM tbl_surat_masuk WHERE kode_surat = '" + ha + "'";
            try
            {
                temp = Fungsi.EQuery(query);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.ToString());
            }
            return temp;
        }

        public void TampilData(string query, string tabel, DataGridView dg)
        {
            try
            {
                dg.DataSource = Fungsi.DataGrid(query, tabel);
                dg.DataMember = tabel;
                dg.Columns[0].HeaderText = "Kode Surat";
                dg.Columns[1].HeaderText = "Kode Jenis Surat";
                dg.Columns[2].HeaderText = "Tanggal Masuk";
                dg.Columns[3].HeaderText = "Kop Surat";
                dg.Columns[4].HeaderText = "No Surat";
                dg.Columns[5].HeaderText = "Perihal";
                dg.Columns[6].HeaderText = "Isi Surat";
                dg.Columns[7].HeaderText = "Pengirim";

                // dg.AutoResizeColumns();
                dg.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dg.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error : " + e.Message);
            }
            finally
            {
            }

        }

    }
}
