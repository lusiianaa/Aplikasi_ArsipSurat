﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace AplikasiArsipSurat
{
    class Koneksi
    {
        private static string conn;
        static Koneksi()
        {
            string connStr = "Data Source=.;Initial Catalog=Aplikasi_ArsipSurat;Integrated Security=True";

            conn = connStr;
        }
        public static SqlConnection Conn
        {
            get
            {
                return new SqlConnection(conn);
            }
        }
    }
}
